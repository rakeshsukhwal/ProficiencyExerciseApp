Compile and Target SDK Version: 28

Design pattern used: MVVM design pattern

Jetpack component used:
- Data Binding
- Live Data
- View Model

NOTE: If the row has valid image URL, the app will download the image and display it. If the image URL is not working, the app will display a place holder image. If the row does not have image URL, it will not display the image.
